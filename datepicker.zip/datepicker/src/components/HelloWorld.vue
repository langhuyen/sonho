<template>
  <div>
    <div class="FormDate" @keyup.capture="updateValue">
       <input
      v-model="valueDate"
      v-imask="mask"
      @accept="onAccept"
      @complete="onComplete">
      <span @click="isDatepicker=!isDatepicker" id="icon-datepicker"></span>
    </div>
    <datepicker
      v-model="valueDatepicker"
      v-if="isDatepicker"
      @close="updateDatepicker"
    ></datepicker>
  </div>
</template>

<script>
  import Datepicker from "./Datepicker.vue";
  import {IMaskDirective} from 'vue-imask';


  export default {
    props:{
      value:{
        type:[String,Date],
        required:true,
      },
      
    },
    data () {
      return {
        valueDate:`${(this.value)?this.formatDate(this.value):""}`,
        valueDatepicker:`${(this.value)?this.value :""}`,
        
        mask: {
          mask: '00{/}00{/}0000',
          lazy: true
        },
        isDatepicker:false,
        onAccept (e) {
          const maskRef = e.detail;
          console.log('accept', maskRef.value);
        },
        onComplete (e) {
          const maskRef = e.detail;
          console.log('complete', maskRef.unmaskedValue);
        }
      }
    },
    watch:{
    
    },
    directives: {
      imask: IMaskDirective
    },
    components:{
      Datepicker,
    },
    methods:{
      formatDate(val) {
      let valuedate = new Date(val);
      let date =
        valuedate.getDate() < 10
          ? "0" + valuedate.getDate()
          : valuedate.getDate();
      let month =
        valuedate.getMonth() < 9
          ? "0" + (valuedate.getMonth() + 1)
          : valuedate.getMonth() + 1;
      return date + "/" + month + "/" + valuedate.getFullYear();
    },
    updateValue(currentKey) {
      //hàm này convert formatDate to Date
      let arr = this.valueDate
        .split("/")
        .reverse()
        .join("-");
      const timestamp = Date.parse(arr);
      if (Number.isNaN(timestamp)) return;
      this.$emit(`input`, timestamp);
      //Update gia tri datepicker
      this.valueDatepicker = timestamp;
    },
    updateDatepicker(){
      isDatepicker=!isDatepicker;
       const timestamp = Date.parse(this.valueDatepicker);
      if (Number.isNaN(timestamp)) return;
      this.valueDate=this.formatDate(timestamp);
    }
    }
  }
</script>

<style lang="scss">
  input{
    border:none;
  }
  .FormDate{border: 1px solid #a8a8a8;
    display: flex;
    width: 237px;}
  #icon-datepicker {
    width: 30px;
    height: 40px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-position-y: 6px;
    background-image: url("../assets/datepicker.png");
  }

</style>