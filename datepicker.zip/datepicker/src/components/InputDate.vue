<template>
  <div class="input-date" @keyup.capture="updateValue">
    <input
      type="text"
      @input="updateDate"
      v-model="valueDate"
      @focus="focusDate"
      @blur="blurDate"
      @click="$refs.inputDate.select()"
      tabindex="0"
      ref="inputDate"
    >
  </div>
</template>
<script>
import { log } from "util";
export default {
  props: {
    value: {
      type: [String, Number],
      required: true
    }
  },
  data() {
    return {
      valueDate: `${this.value ? this.formatDate(this.value) : ""}`,
      mark: "dd/mm/yyyy"
    };
  },
  methods: {
    formatDate(val) {
      let valuedate = new Date(val);
      let date =
        valuedate.getDate() < 10
          ? "0" + valuedate.getDate()
          : valuedate.getDate();
      let month =
        valuedate.getMonth() < 9
          ? "0" + (valuedate.getMonth() + 1)
          : valuedate.getMonth() + 1;
      return date + "/" + month + "/" + valuedate.getFullYear();
    },
    updateValue(currentKey) {
      //hàm này convert formatDate to Date
      let arr = this.valueDate
        .split("/")
        .reverse()
        .join("-");
      const timestamp = Date.parse(arr);
      if (Number.isNaN(timestamp)) return;
      this.$emit(`input`, timestamp);
      //Update gia tri datepicker
      this.valueDatepicker = timestamp;
    },
    updateDate() {
      //format date do ngươi dung nhập
      let key = event.data;

      if (key != 8 && isNaN(key)) {
        //chỉ cho nhập số
        this.valueDate = this.valueDate.slice(0, this.valueDate.length - 1);
        return;
      }
      //thực hiện format
      if (this.valueDate.length == 2) {
        this.valueDate = this.valueDate + "/";
      }
      if (this.valueDate.length == 5) {
        this.valueDate = this.valueDate + "/";
      }
      if (this.valueDate.length > 10) {
        this.valueDate = this.valueDate.slice(0, this.valueDate.length - 1);
      }
    },
    focusDate() {
      if (this.valueDate.length == 0) {
        this.valueDate = this.mark;
        this.$refs.inputDate.classList.add("watermark");
      } else {
        this.$refs.inputDate.classList.remove("watermark");
      }
    },
    blurDate() {
      if (this.valueDate === this.mark) {
        this.valueDate = "";
        this.$refs.inputDate.classList.remove("watermark");
      }
    }
  }
};
</script>

<style scoped>
input.watermark {
  color: #999;
}
input {
  padding: 4px;
  text-indent: 5px;
  width: 200px;
  font-size: 14px;
}
</style>
