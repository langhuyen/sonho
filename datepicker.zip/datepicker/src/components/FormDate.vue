<template>
  <div>
    <div class="FormDate" @keyup.capture="updateValue">
      <input
        v-if="showDay"
        ref="day"
        v-model="day"
        class="FormDate__input FormDate__input--day"
        type="number"
        placeholder="__"
        @input="updateDay"
        @blur="day = day.padStart(2, 0)"
      >
      <span v-if="showDay && showMonth" class="FormDate__divider">/</span>
      <input
        v-if="showMonth"
        ref="month"
        v-model="month"
        class="FormDate__input FormDate__input--month"
        type="number"
        placeholder="__"
        @input="updateMonth"
        @blur="month = month.padStart(2, 0)"
      >
      <span v-if="showYear && (showDay || showMonth)" class="FormDate__divider">/</span>
      <input
        v-if="showYear"
        ref="year"
        v-model="year"
        class="FormDate__input FormDate__input--year"
        type="number"
        placeholder="____"
        @blur="year = year.padStart(4, 0)"
      >
      <span @click="isDatepicker=!isDatepicker" id="icon-datepicker"></span>
    </div>
    <datepicker
      :value="valueDatepicker"
      v-model="valueDatepicker"
      v-if="isDatepicker"
      @close="isDatepicker=!isDatepicker"
    ></datepicker>
  </div>
</template>

<script>
import { log } from "util";
import Datepicker from "./Datepicker.vue";
export default {
  name: `FormDate`,
  components: {
    Datepicker
  },
  props: {
    value: {
      type: [Number, String],
      required: true
    },
    showDay: {
      type: Boolean,
      default: true
    },
    showMonth: {
      type: Boolean,
      default: true
    },
    showYear: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      valueDatepicker: this.value?this.value:new Date(),
      isDatepicker: false,
      day: `${this.value ? new Date(this.value).getDate() : ''}`,
      month: `${this.value ? new Date(this.value).getMonth() + 1 : ''}`,
      year: `${this.value ? new Date(this.value).getFullYear() : ''}`
    };
  },
  watch: {
    year(current, prev) {
    
      if (current > 9999) this.year = prev;
     
    },
   day(current,prev){
  
      if (current > 31) this.day = prev;
   }, 
     month(current,prev){
      if (current > 12) this.month = prev;
   },
   
    valueDatepicker(current) {
      let valueDate = new Date(current);
      let date = valueDate.getDate();
      this.day = date < 10 ? "0" + date : date.toString();

      let month = valueDate.getMonth() + 1;
      this.month = month < 10 ? "0" + month : month.toString();

      this.year = valueDate.getFullYear().toString();
    }
  },
  methods: {
    focus() {
      this.$refs.day.focus();
    },
    updateDay() {
      if (this.day.length< 2) return;
      if (this.showMonth) this.$refs.month.focus();
      else if (this.showYear) this.$refs.year.focus();
    
    },
    updateMonth() {
      console.log("month",this.month.length);
      if (this.month.length<2) {
        console.log("Chua chay vao");
        
        return;}
      if (this.showYear) this.$refs.year.focus();
     
    },
    updateValue() {
      const timestamp = Date.parse(
        `${this.year.padStart(4, 0)}-${this.month}-${this.day}`
      );

      if (Number.isNaN(timestamp)) return;

      this.$emit(`input`, timestamp);
    
     this.valueDatepicker=timestamp;
      
    }
  }
};
</script>

<style lang="scss">
.FormDate {
  $spacing: 0.75em;
  display: inline-flex;
  position: relative;
  overflow: hidden;
  border: 1px solid #888;
  border-radius: 0.25em;
  // 1. Hide the spinner button in Chrome, Safari and Firefox.
  &__input {
    padding: $spacing;
    padding-right: $spacing / 2;
    padding-left: $spacing / 2;
    border: none;
    text-align: center;
    /* stylelint-disable-next-line property-no-vendor-prefix */
    -moz-appearance: textfield; // 1
    &::-webkit-inner-spin-button {
      display: none; // 1
    }
    &:first-child {
      padding-left: $spacing;
    }
    &:last-child {
      padding-right: $spacing;
    }
    &:focus {
      outline: none;
    }
    &--day,
    &--month {
      width: 3em;
    }
    &--year {
      width: 4em;
    }
  }
  &__divider {
    padding-top: $spacing;
    padding-bottom: $spacing;
    pointer-events: none;
  }
  #icon-datepicker {
    width: 30px;
    height: 40px;
    background-repeat: no-repeat;
    background-size: 100%;
    background-position-y: 6px;
    background-image: url("../assets/datepicker.png");
  }
}
</style>