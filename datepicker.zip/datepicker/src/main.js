import Vue from 'vue'
import App from './App.vue'
import Vuesax from 'vuesax'
import 'v2-datepicker/lib/index.css'; // v2 need to improt css
import V2Datepicker from 'v2-datepicker';

Vue.use(V2Datepicker)

Vue.config.productionTip = false
Vue.use(Vuesax);
new Vue({
    render: h => h(App),
}).$mount('#app')