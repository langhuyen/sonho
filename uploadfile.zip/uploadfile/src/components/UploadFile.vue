<template>
    <div class="upload-file" v-bind="$attrs">
        <div class="name-file">
            <div class="icon"></div>
            <div class="name-file-detail">
                
            </div>
            <div class="remove">
                X
            </div>
        </div>
        <div class="upload-file-content" @click="onOpen">
            <div class="drap-file">
                <div class="no-file">
                  <div class="icon"></div>
                    Kéo tệp đính kèm vào đây
                </div>
                <input v-show="false" type="file"  id="input-upload-file" ref="inputFile" multiple @onChange="onChangeInput">
            </div>
            <div class="notify">
                Tối đa 5 tệp, tổng dung lượng nhỏ hơn 10MB, định dạng doc
            </div>

        </div>
    </div>


</template>

<script>

export default {
    name:'msUploadFile',
    props:{},
    data(){
        return {

        }
    },
    watch:{

    },
    computed:{

    },
    methods:{
        onOpen(){

            this.$refs.inputFile.click();
        },
        onChangeInput(){
            this.$refs.inputFile.files;
        }
    },

    
}
</script>

<style scoped>
.name-file {
    background: gray;
    display: flex;
    height: 30px;
    width: 100%;
}
.icon {
    width: 30px;
    height: 30px;
    background-image: url('../assets/linkfile.png');
   background-size: 100%;
    background-repeat: no-repeat;
    background-position-y: 0px;
}
.upload-file-content {
    width: 100%;
    display: flex;
}

.drap-file {
    width: 70%;
    border: 2px dashed #c1c1c1;
}
</style>
